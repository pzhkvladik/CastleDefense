import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {runtime,battleSetup} from './runtime.mjs';

const root=fileURLToPath(new URL('../',import.meta.url));
const r=await runtime(root);
r.run(battleSetup+"game.event='storm';resetVisuals();");

assert.equal(r.run('STORM_CYCLE'),9.5);
assert.ok(r.run('stormFlashAmount(3.16)<=.12'));
assert.equal(r.run('stormFlashAmount(4)'),0);
const majorStrikes=r.run(`(()=>{
  const hits=[];let active=false;
  for(let t=0;t<60;t+=.01){
    const next=stormFlashAmount(t)>.08;
    if(next&&!active)hits.push(t);
    active=next;
  }
  return hits;
})()`);
assert.equal(majorStrikes.length,6);
for(let i=1;i<majorStrikes.length;i++)assert.ok(majorStrikes[i]-majorStrikes[i-1]>9.4);

const before=r.run('JSON.stringify({game,enemies,knights,cavalry,archerTimers})');
const randomCalls=r.stats().randomCalls;
r.run('visual.weatherClock=3.17;drawStormBackdrop();drawStormPuddles();drawStormRain(false);drawStormRain(true);');
assert.equal(r.run('JSON.stringify({game,enemies,knights,cavalry,archerTimers})'),before);
assert.equal(r.stats().randomCalls,randomCalls);
assert.equal(r.stats().depth,0);

for(const speed of [1,12]){
  r.run(`gameSpeed=${speed};visual.weatherClock=0;`);
  r.run('updateVisuals(.016);');
  assert.ok(Math.abs(r.run('visual.weatherClock')-.016)<1e-12);
}
for(const [w,h] of [[800,430],[1280,583],[1440,800]]){
  r.run(`W=${w};H=${h};visual.weatherClock=3.17;draw();`);
  assert.equal(r.stats().depth,0);
}

const effects=await readFile(new URL('../scripts/render-effects.js',import.meta.url),'utf8');
assert.ok(!effects.includes('Math.sin(time*7)>.985'));
assert.ok(!effects.includes("}else if(game.event==='storm'){"));
console.log('PASS  Storm uses rare 9.5s background lightning, speed-independent rain and puddles without full-screen flashes or gameplay/RNG writes');

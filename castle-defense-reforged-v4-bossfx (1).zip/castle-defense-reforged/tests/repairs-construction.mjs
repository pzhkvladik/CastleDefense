import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {runtime} from './runtime.mjs';

const root=fileURLToPath(new URL('../',import.meta.url));
const [html,css,economy,simulation]=await Promise.all([
  readFile(new URL('../index.html',import.meta.url),'utf8'),
  readFile(new URL('../styles/main.css',import.meta.url),'utf8'),
  readFile(new URL('../scripts/economy-ui.js',import.meta.url),'utf8'),
  readFile(new URL('../scripts/simulation.js',import.meta.url),'utf8')
]);

const repairGroup=html.match(/<div class="shopGroup" data-shop-group="repair">([\s\S]*?)<\/div>/)?.[1]||'';
assert.match(html,/id="repairTab"[^>]*data-tab="repair"/);
assert.match(repairGroup,/id="repairBtn"/);
assert.match(repairGroup,/id="towerRepairBtn"/);
assert.equal((html.match(/id="repairBtn"/g)||[]).length,1);
assert.equal((html.match(/id="towerRepairBtn"/g)||[]).length,1);
assert.match(css,/\.shopTab\.repairCritical/);
assert.match(css,/@keyframes repairCritical/);
assert.match(economy,/gateHp\/game\.gateMax<\.15\|\|game\.towerHp\/game\.towerMax<\.15/);
console.log('PASS  Dedicated repair tab contains both repairs and pulses below the exact 15% castle/artillery threshold');

const cloudLoop=simulation.slice(simulation.indexOf('for(const c of clouds)'),simulation.indexOf('// arrows'));
assert.ok(!cloudLoop.includes('game.flash='));
const r=await runtime(root);
r.run(`newGame();game.waveTotal=99;game.spawned=99;game.wavePause=999;
  spawnEnemy('normal');enemies[0].x=620;game.flash=0;game.mageLevel=2;castMage();`);
r.run('update(.1);update(.1);');
assert.ok(r.run('lightnings.length>0'));
assert.equal(r.run('game.flash'),0);
console.log('PASS  Mage lightning remains locally visible without writing the full-screen flash state');

r.run('newGame();game.gold=9999;buyRiver();');
assert.equal(r.run('game.river'),true);
assert.equal(r.run('visual.moatBuild.t'),0);
r.run('visual.moatBuild.t=5;buyRiver();');
assert.equal(r.run('visual.moatBuild.t'),5,'River upgrades must not restart the first-build vignette');
assert.equal(r.run('moatConstructionWaterLevel()'),0);
r.run('visual.moatBuild.t=6.86;');
assert.ok(Math.abs(r.run('moatConstructionWaterLevel()')-.5)<1e-10);
r.run('visual.moatBuild.t=10.84;');assert.equal(r.run('moatConstructionShowsAlligators()'),false);
r.run('visual.moatBuild.t=10.85;');assert.equal(r.run('moatConstructionShowsAlligators()'),true);

for(const [w,h] of [[800,430],[1280,583],[1440,800]]){
  for(const phase of [.5,2.6,6.4,8.7,10.7,12.2]){
    r.run(`W=${w};H=${h};visual.moatBuild={t:${phase}};`);
    const before=r.run('JSON.stringify({game,enemies,alligators,knights,cavalry})');
    const randomCalls=r.stats().randomCalls;
    r.run('drawRiver();drawMoatConstruction();');
    assert.equal(r.run('JSON.stringify({game,enemies,alligators,knights,cavalry})'),before);
    assert.equal(r.stats().randomCalls,randomCalls);
    assert.equal(r.stats().depth,0);
  }
}
r.run('visual.moatBuild={t:0};for(let i=0;i<268;i++)updateVisuals(.05);');
assert.equal(r.run('visual.moatBuild'),null);
console.log('PASS  First moat build runs through digging, water, bound-alligator throw and return without gameplay/RNG writes');

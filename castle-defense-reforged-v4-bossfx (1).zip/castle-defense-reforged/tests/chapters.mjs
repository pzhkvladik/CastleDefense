import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {runtime,battleSetup} from './runtime.mjs';

const root=fileURLToPath(new URL('../',import.meta.url));
const r=await runtime(root);
r.run(battleSetup+'resetVisuals();');

for(const [wave,id] of [[1,'greenlands'],[10,'greenlands'],[11,'winter'],[20,'winter'],[21,'darkForest'],[30,'darkForest'],[31,'volcanic'],[40,'volcanic'],[41,'demonic'],[50,'demonic']]){
  r.run(`game.wave=${wave};`);
  assert.equal(r.run('visualChapter().id'),id);
}
console.log('PASS  Waves 1-50 switch at the five chapter boundaries');

const colors=[];
for(const wave of [5,15,25,35,45]){
  r.run(`game.wave=${wave};`);
  colors.push(r.run("chapterEnemyPalette({type:'normal'},SEASONS[0]).goblinSkin"));
}
assert.equal(new Set(colors).size,5);
r.run('game.wave=45;');
r.run('game.wave=45;');
assert.equal(r.run("chapterEnemyPalette({type:'boss'},SEASONS[0]).bossName"),'Demon Archfiend');
console.log('PASS  Enemies and bosses use the active chapter palette');

const before=r.run('JSON.stringify({game,enemies,knights,arrows,stones})');
const randomBefore=r.stats().randomCalls;
for(const wave of [5,15,25,35,45]){
  r.run(`game.wave=${wave};drawChapterEnvironment();for(const e of enemies)drawGoblin(e);`);
  assert.equal(r.stats().depth,0);
}
assert.equal(r.run('JSON.stringify({game,enemies,knights,arrows,stones})'),before);
assert.equal(r.stats().randomCalls,randomBefore);
console.log('PASS  All chapter scenes draw without changing gameplay state or RNG');

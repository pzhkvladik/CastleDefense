import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {runtime} from './runtime.mjs';

const root=fileURLToPath(new URL('../',import.meta.url));
const r=await runtime(root);

// No target means no wasted gold and no phantom riders.
r.run('newGame();game.gold=BALANCE.cavalry.cost;deployCavalry();');
assert.equal(r.run('game.gold'),r.run('BALANCE.cavalry.cost'));
assert.equal(r.run('cavalry.length'),0);

// A sortie must flank and destroy an actual enemy catapult, then ride home.
r.run(`
  newGame();game.gold=BALANCE.cavalry.cost;game.waveTotal=1;game.spawned=1;game.wavePause=999;
  spawnEnemy('catapult');enemies[0].x=gateX()+430;enemies[0].specialTimer=999;
  const cavalryVictim=enemies[0];deployCavalry();
`);
assert.equal(r.run('game.gold'),0);
assert.equal(r.run('cavalry.length'),2);
assert.equal(r.run('game.cavalryCooldown'),r.run('BALANCE.cavalry.cooldown'));
r.run('for(let i=0;i<420&&!cavalryVictim.dead;i++){updateVisuals(1/60);update(1/60);draw();}');
assert.equal(r.run('cavalryVictim.dead'),true);
assert.ok(r.run('cavalryVictim.x<cavalry.reduce((m,r)=>Math.min(m,r.x),Infinity)'),
  'Riders must be on the far side when the catapult is defeated');
r.run('for(let i=0;i<500&&cavalry.length;i++){updateVisuals(1/60);update(1/60);draw();}');
assert.equal(r.run('cavalry.length'),0);
assert.equal(r.stats().depth,0);
console.log('PASS  Cavalry costs nothing without a target; flanks an enemy catapult, destroys it and returns home');

// Resize and x12 should keep horse coordinates finite and feet on the ground.
r.run(`
  newGame();game.gold=9999;game.waveTotal=99;game.spawned=99;game.wavePause=999;
  spawnEnemy('catapult');enemies[0].x=1100;enemies[0].specialTimer=999;deployCavalry();gameSpeed=12;
`);
for(const [w,h] of [[800,430],[1280,583],[1440,800]]){
  r.run(`W=${w};H=${h};for(let i=0;i<30;i++){updateVisuals(1/60);update(.2);draw();}`);
  assert.ok(r.run('cavalry.every(r=>Number.isFinite(r.x)&&r.y===groundY()-6)'));
  assert.equal(r.stats().depth,0);
}
console.log('PASS  Mounted sortie remains grounded and renders safely after resize at x12');
